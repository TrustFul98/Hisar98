var snakefeld = document.getElementById("snakefeld");
var snakefeldstyle = snakefeld.style;
var snakefelddivs;
var gridanzahl = "";
var kopf = 209;
var teile = 3;
var koerperteile = new Array(teile);
var vx = 0;
var vy = -20;
var vk = vy + vx;
var schleifezaehler = 0;
var kaki = 1.0;
let newELementKAKI = 0;
let vorher = 0;
let nachher = teile;
var schalter = true;
var name;
var code;
var punkte = document.querySelector("#points");

//Gridanzahl SPalte/ Zeile
for (let i = 0; i < 20; i++) {
  gridanzahl = gridanzahl + 1 + "fr ";
}
snakefeldstyle.gridTemplateColumns = gridanzahl;
snakefeldstyle.gridTemplateRows = gridanzahl;

//Feld füllen mit Divs
for (let i = 0; i < Math.pow(20, 2); i++) {
  var newelement = document.createElement("div");
  snakefeld.appendChild(newelement);
  newelement.classList = "snakefelddivs " + schleifezaehler;
  schleifezaehler++;
}
schleifezaehler = 0;
snakefelddivs = snakefeld.querySelectorAll("div");

//Erstes Stück Futter
var food = document.createElement("div");
var generator = Math.floor(Math.random() * snakefelddivs.length);
food.classList = "food";
snakefelddivs[generator].appendChild(food);

//Malen des Körpers zu Beginn
for (let i = kopf; i < kopf + 60; i += 20) {
  snakefelddivs[i].style.backgroundColor = "black";
  if (schleifezaehler != koerperteile) {
    koerperteile[schleifezaehler] = i;
    schleifezaehler++;
  } else {
    schleifezaehler = 0;
  }
}

//Punktezähler aktivieren
punkte.innerHTML = teile - 3;

intervalFOODY();

//Intervall Bewegung des Körpers
let interval = setInterval(function () {
  arrowDirection();

  kopf = kopf + vk;

  //Randmaximum festlegen
  if (
    kopf > 399 ||
    kopf < 0 ||
    (kopf % 20 == 19 && vk == -1) ||
    (kopf % 20 == 0 && vk == 1)
  ) {
    document.querySelector("#message").style.display = "flex";
    clearInterval(interval);
    clearInterval(foodsinterval);
  } else {
    snakefelddivs[koerperteile[teile - 1]].style.backgroundColor = "yellow";

    // Werte übergeben um fortzubewegen
    for (let i = teile - 1; i >= 0; i--) {
      if (i > 0) {
        koerperteile[i] = koerperteile[i - 1];
      } else {
        koerperteile[0] = kopf;
      }
    }

    //dank neue Werte neuen Körper malen hhhhh
    for (let i = 0; i < teile; i++) {
      snakefelddivs[koerperteile[i]].style.backgroundColor = "black";

      //ClassList anpassen
      if (i == teile - 1) {
        snakefelddivs[koerperteile[i]].classList =
          snakefelddivs[koerperteile[i]].classList[0] +
          " " +
          snakefelddivs[koerperteile[i]].classList[1];
      }
    }

    //Wenn er an sich selber knabbert Game Over!
    for (let a = 4; a < koerperteile.length; a++) {
      if (
        snakefelddivs[kopf].classList[1] ==
        snakefelddivs[koerperteile[a]].classList[1]
      ) {
        clearInterval(interval);
        clearInterval(foodsinterval);
        document.querySelector("#message").style.display = "flex";
      }
    }

    //Kaka machen
    vorher = nachher;
    nachher = teile;

    if (vorher < kaki * 10 && nachher >= kaki * 10) {
      newELementKAKI = document.createElement("div");
      snakefelddivs[koerperteile[teile - 1]].appendChild(newELementKAKI);
      newELementKAKI.classList = "kaki";

      //TimeOuter setzen, um Kaki zu befristen

      setTimeout(function () {
        if (document.querySelectorAll(".kaki").length != 0) {
          document
            .querySelector(".kaki")
            .parentNode.removeChild(document.querySelector(".kaki"));
        }
      }, 10000);
      kaki++;
    }

    //Futter fressen
    //TODO: Hier noch ausbessern
    if (
      document.querySelector(".food").parentNode.classList[1] ==
      snakefelddivs[kopf].classList[1]
    ) {
      //Wenn True: zum Körper-Array eins hinzufügen
      clearInterval(foodsinterval);
      prepaidFOODY();
      teile++;
      punkte.innerHTML = teile - 3;
      koerperteile.push();
      koerperteile[teile - 1] = koerperteile[teile - 2];
      snakefelddivs[kopf].classList =
        snakefelddivs[kopf].classList[0] +
        " " +
        snakefelddivs[kopf].classList[1] +
        " scalinghead";
    }

    //Kaki fressen
    if (document.querySelectorAll(".kaki").length != 0) {
      if (
        document.querySelector(".kaki").parentNode.classList[1] ==
        snakefelddivs[kopf].classList[1]
      ) {
        //altes shit wegnehmen
        document
          .querySelector(".kaki")
          .parentNode.removeChild(document.querySelector(".kaki"));

        //3 mal zu Körper-Array hinzufügen
        teile += 3;
        punkte.innerHTML = teile - 3;
        koerperteile.push(0, 0, 0);
        //TODO: Alte Kakis zeitlich begrenzen, nach fressen wegbiemen
        // dasgleiche für fodies
        for (let i = teile - 4; i < teile; i++) {
          koerperteile[i + 1] = koerperteile[i];
        }

        snakefelddivs[kopf].classList =
          snakefelddivs[kopf].classList[0] +
          " " +
          snakefelddivs[kopf].classList[1] +
          " scalinghead";
      }
    }
  }
}, 200);

//Futter beamen zeitlich
let foodsinterval = setInterval(intervalFOODY, 5000);

function intervalFOODY() {
  snakefelddivs[generator].removeChild(document.querySelector(".food"));
  //TODO: Hier nochmal probieren mit zeitgrenze zu optimieren
  food = document.createElement("div");
  generator = Math.floor(Math.random() * snakefelddivs.length);
  food.classList = "food";
  snakefelddivs[generator].appendChild(food);
}

function prepaidFOODY() {
  snakefelddivs[generator].removeChild(document.querySelector(".food"));
  //TODO: Hier nochmal probieren mit zeitgrenze zu optimieren
  food = document.createElement("div");
  generator = Math.floor(Math.random() * snakefelddivs.length);
  food.classList = "food";
  snakefelddivs[generator].appendChild(food);
  foodsinterval = setInterval(intervalFOODY, 5000);
}

//KeyListener; Falls mehrere Tasten gedrückt werden, wird nur der letzte global gespeichert
document.addEventListener("keydown", (element) => {
  code = element.code;
});

//Der Global gespeicherte Werte wird angesprochen!
function arrowDirection() {
  switch (code) {
    case "ArrowUp":
      if (vy != 20) {
        vy = -20;
        vx = 0;
      }
      break;
    case "ArrowDown":
      if (vy != -20) {
        vy = 20;
        vx = 0;
      }
      break;
    case "ArrowLeft":
      if (vx != 1) {
        vy = 0;
        vx = -1;
      }
      break;
    case "ArrowRight":
      if (vx != -1) {
        vy = 0;
        vx = 1;
      }
      break;
  }
  vk = vx + vy;
}

document.querySelector("button").onclick = function () {
  window.location.reload();
};
