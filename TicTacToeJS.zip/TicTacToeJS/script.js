"use strict";

const spielfeld = document.querySelector("#spielfeld");
let pixel;
let zaehler = 0;
let punktestand = [];
let player1 = true;
let player2 = false;

for (let i = 0; i < 3; i++) {
  for (let a = 0; a < 3; a++) {
    const element = document.createElement("div");
    spielfeld.appendChild(element);
    element.classList = "pixel " + zaehler;
    element.style.gridColumn = a + 1 + "/" + (a + 2);
    element.style.gridRow = i + 1 + "/" + (i + 2);
    punktestand.push(undefined);
    zaehler++;
  }
}

zaehler = 0;
pixel = document.querySelectorAll(".pixel");

for (let f = 0; f < punktestand.length; f++) {
  pixel[f].onclick = function () {
    if (pixel[f].innerHTML == "" && zaehler < 9) {
      if (player1) {
        pixel[f].innerHTML = "X";
        punktestand.splice(f, 1, "X");
        console.log(punktestand[f + 1]);
        player1 = false;
        player2 = true;
      } else {
        pixel[f].innerHTML = "O";
        punktestand.splice(f, 1, "O");
        player1 = true;
        player2 = false;
      }
      zaehler++;

      setTimeout(spielstandPruefen, 100);
      if (zaehler === 9) {
        punktestandZuruecksetzen();
      }
    }
  };
}

function spielstandPruefen() {
  dreierReihePruefen(1, 2, 3);
  dreierReihePruefen(4, 5, 6);
  dreierReihePruefen(7, 8, 9);
  dreierReihePruefen(1, 4, 7);
  dreierReihePruefen(2, 5, 8);
  dreierReihePruefen(3, 6, 9);
  dreierReihePruefen(1, 5, 9);
  dreierReihePruefen(3, 5, 7);
}

function dreierReihePruefen(element1, element2, element3) {
  const feld1 = parseInt(element1) - 1;
  const feld2 = parseInt(element2) - 1;
  const feld3 = parseInt(element3) - 1;

  if (
    punktestand[feld1] === punktestand[feld2] &&
    punktestand[feld2] === punktestand[feld3] &&
    punktestand[feld1] !== undefined
  ) {
    if (punktestand[feld1] === "X") {
      window.alert("Player1 wins");
    } else {
      window.alert("Player2 wins");
    }
    punktestandZuruecksetzen();
  }
}

function punktestandZuruecksetzen() {
  for (let x = 0; x < punktestand.length; x++) {
    punktestand.splice(x, 1, undefined);
    pixel[x].innerHTML = "";
  }
  zaehler = 0;
}
