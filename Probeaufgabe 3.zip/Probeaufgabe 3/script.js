//Wir wollen nun die 8*8 Kästen inform von Containern einfügen.
let layout = document.getElementById("layout"); //layout
let zaehler = 1; //Um die einzelnen Divs mit einer Classe zu versehen 1-max;
let canvasParent = document.querySelector("#canvas"); //Das Parent zum canvas, auf dem das Gemälde projiziert wird.
let format = "bild.png";
let elm = document.querySelector("#canvas");
let schalter = 0; // ON-/ OFF-Schaltung für Pinsel
let schalter2 = 0; // ON-/ OFF-Schaltung für Raddierer
let schalter3 = 0; // ON-/ OFF-Schaltung für ?-Button
let farbe = "yellow"; //aktuelle Farbe
let farbedavor = farbe; //vorherige Farbe (Buffer für die vorherige Farbe)
let layoutsdivs = 64; //Startwert: 8x8 Basisgrid = 64 Kästchen. Anzahl Divs(Pixel) im Layout
let amount = 8; //Stellt Kästchen pro Zeile/ Spalte dar
//Layout mit 64 Kästchen
for (let a = 0; a < layoutsdivs; a++) {
  let createDiv = document.createElement("div");
  layout.appendChild(createDiv);
  createDiv.classList = zaehler;
  createDiv.style.backgroundColor = "white";
  zaehler++;
}
zaehler = 1;

//Neue Div-Anzahl wird gespeichert
layoutsdivs = layout.querySelectorAll("div");

//Klick auf div=farbiger Hintergrund
for (let i = 0; i < layoutsdivs.length; i++) {
  layoutsdivs[i].onclick = function () {
    layoutsdivs[i].style.backgroundColor = farbe;
  };
}

//Ersatz für CSS-Hover Effekt.
for (let i = 0; i < layoutsdivs.length; i++) {
  let farbevorher = layoutsdivs[i].style.borderColor;
  layoutsdivs[i].onmouseover = function () {
    layoutsdivs[i].style.borderColor = farbe;
  };
  layoutsdivs[i].onmouseout = function () {
    layoutsdivs[i].style.borderColor = farbevorher;
  };
}

//Übergibt die gewünschte Farbe. Welche? Diese Info steckt in der ClassList[1] des angesprochen Elements (s. HTML-Skript);
function paint(element) {
  farbe = element.classList[1];
  farbedavor = farbe;
  layoutsdivs = layout.querySelectorAll("div");
  for (let i = 0; i < layoutsdivs.length; i++) {
    let farbevorher = layoutsdivs[i].style.borderColor;
    layoutsdivs[i].onmouseover = function () {
      layoutsdivs[i].style.borderColor = farbe;
    };
    layoutsdivs[i].onmouseout = function () {
      layoutsdivs[i].style.borderColor = farbevorher;
    };
    //Falls Rubber aktiviert ist, wird durch Auswahl der Farbe Rubber deaktiviert!
    schalter2 = 1;
    rubber();
  }
}

//Bestimmung der Height und Width des Layouts (Ohne Divs(Pixel). Lediglich das Grid!)
function gridsize(element) {
  // Layout wird gestylet
  var stylepal = layout.style;

  //Falls ?-Button aktiv, so wird es nun deaktiviert!
  schalter3 = 1;
  help();

  //ClassList von element besitzt den Wert, der bestimmt wie viele Zeilen und Spalten es gibt
  amount = parseInt(element.classList);

  //Gesamtgröße des Layouts festlegen. (ohne Grid)
  stylepal.height = amount * 15 + "px";
  stylepal.width = amount * 15 + "px";

  //datensatz sammelt Summe der Addition in der Schleife.
  var datensatz = "";

  //amount = Anzahl Zeilen/ Spalten
  for (let i = 0; i < amount; i++) {
    datensatz = datensatz + 1 + "fr" + " ";
  }

  //datensatz: Anzahl der Zeilen bzw Spalten im Grid-Layout.
  stylepal.gridTemplateRows = datensatz;
  stylepal.gridTemplateColumns = datensatz;
  //Für Neusetzung datensatz wieder auf "" (0 setzen)
  datensatz = "";
}

//Zu gridsize(): Nach erstellen des Grid-Layouts wird jedes Grid-Feld ausgefüllt mit Divs(Pixel)
function fillpalette(element) {
  //Alle Buttons außer das angeklickte pink färben. Das angeklickte schwarz. Aktivierungszeichen.
  let gridgrdivs = document
    .querySelector(".gridgroesse")
    .querySelectorAll("div");
  for (let i = 0; i < gridgrdivs.length; i++) {
    gridgrdivs[i].style.backgroundColor = "hotpink";
  }
  element.style.backgroundColor = "black";

  //Divs(Pixel) aus anderen Projekten werden gelöscht.
  for (let f = layoutsdivs.length - 1; f >= 0; f--) {
    layoutsdivs[f].parentNode.removeChild(layoutsdivs[f]);
  }

  //Jedes Grid-Feld des Layouts wird mit einem Div gefüllt(Pixel)
  for (let a = 0; a < Math.pow(amount, 2); a++) {
    let createDiv = document.createElement("div");
    layout.appendChild(createDiv);
    createDiv.classList = zaehler;
    createDiv.style.backgroundColor = "white";
    zaehler++;
  }
  //Neue Anzahl der Divs wird gespeichert
  layoutsdivs = layout.querySelectorAll("div");

  //Beim Umschalten der Gridgröße wird automatisch der Farbeimer(fontweight()) deaktiviert!
  schalter = 1;
  fontweight();

  zaehler = 1;
}

//Layout zurücksetzen mit Button NEU
function refresh() {
  //Mit schalter 1 (0=On; 1=Off) Farbeimer(fontweight()) deaktivieren
  schalter = 1;
  fontweight();

  //Alle Divs(Pixel) werden wieder weiß gefärbt
  for (let i = layoutsdivs.length - 1; i >= 0; i--) {
    layoutsdivs[i].style.backgroundColor = "white";
  }
}

//Rubber wird gesteuert mit 1/0 (OFF=1/On=0)
//Aktiv= Hintergrundfarbe des Button wird pink; Deaktiv.= Hintergrund des Button wird weiß;
function rubber() {
  var activerubber = document.querySelector(".rubber").querySelector("i").style;
  if (schalter2 == 0) {
    //Rubber gibt dem Pixel wieder eine weiße Farbe
    activerubber.backgroundColor = "hotpink";
    activerubber.color = "white";
    farbe = "white";
    //Verursacht, dass mein nächsten Aufruf else ausgeführt wird
    schalter2++;
  } else {
    // Wenn Rubber deaktiviert wird, so bekommt der Pinsel wieder seine Ursprungsfarbe;
    activerubber.backgroundColor = "white";
    activerubber.color = "hotpink";
    farbe = farbedavor;
    //verursacht, dass beim nächsten Aufruf if ausgeführt wilayouts
    schalter2--;
  }
}

//Hiert wird das gewählte Format in einem String gespeichert
function chooseFormat(element) {
  //Das angeklickte Tag wird schwarz gefärbt (ButtonActive!)
  let imgformatdivs = document
    .querySelector(".imgformat")
    .querySelectorAll("div");
  for (let i = 0; i < imgformatdivs.length; i++) {
    imgformatdivs[i].style.backgroundColor = "hotpink";
  }
  element.style.backgroundColor = "black";

  //Substring bildet das String "bild.", an den das ausgesuchte Format mit concat angehängt wird (jpg/ gif/ png)
  format = format.substring(0, 5);
  format = format.concat(element.classList[1]);
}

//div wird downloadfähig gemacht
//FIXME: Canvas genutzt, da von HTML sonst nicht die Möglichkeit besteht einen Div zu downloaden
function convert() {
  //1. Das alte canvas-Tag aus altem Projekt wird gelöscht.(falls vorhanden)
  if (elm.getElementsByTagName("canvas").length > 0) {
    for (let i = elm.getElementsByTagName("canvas").length - 1; i >= 0; i--) {
      elm.removeChild(elm.getElementsByTagName("canvas")[i]);
    }
  }
  //2. palette(ist das Layout) wird auf canvas gemalt
  html2canvas(layout).then(function (canvas) {
    //3. canvas wird in ein Div-Tag integriert (id="canvas")
    elm.appendChild(canvas);
    //4. integrierter Canvas-Tag bekommt Class zugeschrieben
    xexe = elm.getElementsByTagName("canvas")[0];
    xexe.classList = "canvasC";
    //5. URI bekommt die URL zugewiesen
    const URI = xexe.toDataURL();
    //a-Tag zum downloaden bekommt die URL zugewiesen
    document.querySelector("#downloader").href = URI;
    //download bekommt den ausgesuchten format von chooseFormat() zugewiesen
    document.querySelector("#downloader").download = format;
    //und schließlich wird das Canvas via automatischem Klick mit gewünschtem Format gedownloadet
    document.querySelector("#downloader").click();
  });
}

//Farbeimer wird aktiviert
function fontweight() {
  var activepinsel = document
    .querySelector(".farbeimer")
    .querySelector("i").style;
  if (schalter == 0) {
    //Farbeimer-Button aktiviert verdeutlichen
    activepinsel.backgroundColor = "hotpink";
    activepinsel.color = "white";

    //Mathematische Bedingungen setzen, wann gewisse Felder angesprochen werden dürfen und wann nicht
    //amount=Pixel pro Zeile/ Spalte
    for (let i = 0; i < layoutsdivs.length; i++) {
      layoutsdivs[i].onclick = function () {
        //Die letzte Zeile darf nicht angeklickt werden
        if (i < layoutsdivs.length - amount) {
          //Beide Divs(Pixel) müssen selbe bg-farbe besitzen (/**/= Selbe Bedingung)
          if (
            layoutsdivs[i].style.backgroundColor ==
            layoutsdivs[i + amount].style.backgroundColor
          ) {
            layoutsdivs[i + amount].style.backgroundColor = farbe;
          }

          //Weder die 1. Spalte noch die letze Zeile darf angeklickt werden
          if (i % amount > 0) {
            /**/ //Siehe Oben
            if (
              layoutsdivs[i].style.backgroundColor ==
              layoutsdivs[i + amount - 1].style.backgroundColor
            ) {
              layoutsdivs[i + amount - 1].style.backgroundColor = farbe;
            }
          }

          //Weder die letzte Spalte noch die letzte Zeile darf angeklickt werden
          if (i % amount < amount - 1) {
            /**/
            if (
              layoutsdivs[i].style.backgroundColor ==
              layoutsdivs[i + amount + 1].style.backgroundColor
            ) {
              layoutsdivs[i + amount + 1].style.backgroundColor = farbe;
            }
          }
        }

        //Die letzte Spalte darf nicht angeklickt werden
        if ((i + 1) % amount != 0) {
          /**/
          if (
            layoutsdivs[i].style.backgroundColor ==
            layoutsdivs[i + 1].style.backgroundColor
          ) {
            layoutsdivs[i + 1].style.backgroundColor = farbe;
          }
        }

        //Die erste Spalte darf nicht angeklickt werden
        if ((i + 1) % amount != 1) {
          /**/
          if (
            layoutsdivs[i].style.backgroundColor ==
            layoutsdivs[i - 1].style.backgroundColor
          ) {
            layoutsdivs[i - 1].style.backgroundColor = farbe;
          }
        }

        //Erst ab der 2. Zeile darf über der Farbmitte ein Feld gefärbt werden
        if (i > amount - 1) {
          /**/
          if (
            layoutsdivs[i].style.backgroundColor ==
            layoutsdivs[i - amount].style.backgroundColor
          ) {
            layoutsdivs[i - amount].style.backgroundColor = farbe;
          }
          //Erst ab der 2. Zeile und ab der 2. Spalte möglich
          if (i % amount > 0) {
            /**/
            if (
              layoutsdivs[i].style.backgroundColor ==
              layoutsdivs[i - amount - 1].style.backgroundColor
            ) {
              layoutsdivs[i - amount - 1].style.backgroundColor = farbe;
            }
          }
          //Erst ab der 2. Zeile und bis zur vorletzten Spalte anklickbar
          if (i % amount < amount - 1) {
            /**/
            if (
              layoutsdivs[i].style.backgroundColor ==
              layoutsdivs[i - amount + 1].style.backgroundColor
            ) {
              layoutsdivs[i - amount + 1].style.backgroundColor = farbe;
            }
          }
        }
        layoutsdivs[i].style.backgroundColor = farbe;
      };
    }
    //Zweck: Alle umliegenden Divs(Pixel) mit derselben Farbe werden mitgefärbt.
    //Außer wenn an Stellen geklickt wird, die die Bedingungen einzelner Nachbarfelder nicht erfüllen.
    //Axiome:
    //1. An der betroffenen Stelle muss ein Div(Pixel) vorliegen (Der Mantel)
    //2. Die einzelnen Divs(Pixel) des Mantels müssen die gleiche Farbe besitzen

    schalter++;
  } else {
    //Farbeimer-Button deaktiviert verdeutlichen
    activepinsel.backgroundColor = "white";
    activepinsel.color = "hotpink";

    //Wenn Farbeimer deaktiviert, so wird wieder nur das mittlere alleine ausgefüllt
    for (let i = 0; i < layoutsdivs.length; i++) {
      layoutsdivs[i].onclick = function () {
        layoutsdivs[i].style.backgroundColor = farbe;
      };
    }
    schalter--;
  }
}

//ON/OFF Schaltung für ?-Button
function help() {
  let buttonhelp = document.querySelector(".help").querySelector("i").style;
  let helptext = document.querySelector(".helptext").style;
  if (schalter3 == 0) {
    buttonhelp.backgroundColor = "hotpink";
    buttonhelp.color = "white";

    helptext.display = "flex";
    helptext.height = amount * 15 + "px";
    helptext.width = amount * 15 + "px";
    schalter3++;
  } else {
    buttonhelp.backgroundColor = "white";
    buttonhelp.color = "hotpink";

    helptext.display = "none";
    helptext.height = 0;
    helptext.width = 0;
    schalter3--;
  }
}

//TODO: Mach noch ein ?-Button, mit dem du eine kleine Anleitung schreibst!

//FIXME:    Einen Div in eine Bilddatei umzuwandeln habe ich nach aktuellen Recherchen mit HTML/ CSS oder JS alleine nicht
//          gefunden allerdings bin ich auf die cansas Bibliothek gestoßen und finde das echt nett. :D
//          Ich habe zuerst die Bilddatei konvertiert und muss das eig danach downloaden. Da das für den Nutzer
//          Probleme bringt und zu umständlich ist habe ich das automatisiert mit click();
