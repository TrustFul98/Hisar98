"use strict";

let zaehler = 1;
let objekte;
let pixel;
let puffer = [,];
let zufallszahl;
let interval;
let maxfelder = [];
let schalter = true;
let keyaction = new Set([]);
let fps = 0.5;
let linksprüfenaufblack;
let rechtsprüfenaufblack;
let klappe = true;
let verfügbarobjekt;
let verfügbarkeitpuffer;

objekteWertzurücksetzung();
zufallsZahlFürObjekt();
feldAusfüllen();
intervalSetzen();

function objekteWertzurücksetzung() {
  objekte = [
    [-31, -10, -30, -50, -29],
    [-32, -12, -11, -10, -9],
    [-29, -9, -10, -11, -12],
    [-90, -70, -50, -30, -10],
  ];
}

function zufallsZahlFürObjekt() {
  zufallszahl = Math.round(Math.random() * objekte.length - 0.5);
}

function feldAusfüllen() {
  for (let i = 0; i < 500; i++) {
    const element = document.createElement("div");
    document.querySelector("#spielfeld").appendChild(element);
    element.classList = "pixel " + zaehler;
    zaehler++;
  }
  zaehler = 0;
  pixel = document.querySelectorAll(".pixel");
}

function intervalSetzen() {
  interval = setInterval(function () {
    window.requestAnimationFrame(function () {
      verfügbarkeitObjekt();
      zeileErmitteln();
      trueOrFalse();
      objektMalen(verfügbarobjekt);
      volleReihe();
      restartInterval();
      objekteWerteNeusetzen();
    });
  }, 1000 / fps);
}

function verfügbarkeitObjekt() {
  verfügbarobjekt = [];

  for (let i = 0; i < objekte[zufallszahl].length; i++) {
    if (objekte[zufallszahl][i] >= 0) {
      verfügbarobjekt.push(objekte[zufallszahl][i]);
    }
  }
}

function zeileErmitteln() {
  if (Math.max.apply(null, verfügbarobjekt) < 500) {
    for (let i = 0; i < verfügbarobjekt.length; i++) {
      if (!verfügbarobjekt.includes(verfügbarobjekt[i] + 20)) {
        maxfelder.push(verfügbarobjekt[i]);
      }
    }
  }
}

function trueOrFalse() {
  const prüfen = (element) => pixel[element].style.backgroundColor !== "black";
  if (Math.max.apply(null, verfügbarobjekt) < 500 && maxfelder.every(prüfen)) {
    schalter = true;
  } else {
    schalter = false;
    zaehler = 0;
  }
  maxfelder = [];
}

function objektMalen(element) {
  if (schalter) {
    pufferWerte();
    körperMalen(element);
    zaehler++;
  }
}

function pufferWerte() {
  //Alter Werte werden zwischengespeichert und genutzt.
  if (zaehler > 0) {
    vorgängerLöschen(puffer[0]);
  }
  puffer[0] = objekte[zufallszahl];
}

function vorgängerLöschen(nr) {
  verfügbarkeitpuffer = [];
  for (let i = 0; i < nr.length; i++) {
    if (puffer[0][i] >= 0) {
      verfügbarkeitpuffer.push(nr[i]);
    }
  }
  for (let i = 0; i < verfügbarkeitpuffer.length; i++) {
    pixel[verfügbarkeitpuffer[i]].style.backgroundColor = "orangered";
  }
}

function körperMalen(object) {
  let koerperpuffer = [];
  for (let i = 0; i < object.length; i++) {
    if (object[i] >= 0) {
      koerperpuffer.push(object[i]);
    }
  }
  for (let i = 0; i < koerperpuffer.length; i++) {
    pixel[koerperpuffer[i]].style.backgroundColor = "black";
  }
}

function volleReihe() {
  if (!schalter) {
    const zeile = puffer[0].map((element) => Math.round(element / 20 - 0.5));
    let vollereihe = [[], [], [], [], []];

    for (let x = 0; x < zeile.length; x++) {
      for (let i = zeile[x] * 20; i < zeile[x] * 20 + 20; i++) {
        if (pixel[i].style.backgroundColor === "black") {
          vollereihe[x].push(true);
        } else {
          vollereihe[x].push(false);
        }
      }
    }

    const völleprüfen = (element) => element === true;

    for (let x = 0; x < zeile.length; x++) {
      if (vollereihe[x].every(völleprüfen)) {
        for (let i = zeile[x] * 20; i < zeile[x] * 20 + 20; i++) {
          pixel[i].style.backgroundColor = "orangered";
        }
      }
    }
  }
}

function restartInterval() {
  if (!schalter) {
    clearInterval(interval);
    zufallsZahlFürObjekt();
    objekteWertzurücksetzung();
    intervalSetzen();
  }
}

function objekteWerteNeusetzen() {
  objekte[zufallszahl] = objekte[zufallszahl].map((x) => x + 20);
}

document.onkeydown = function (element) {
  const key = element.key;
  keyaction.add(key);
  if (key === "ArrowDown") {
    keyboardDown();
  }
  if (key === "ArrowLeft" || key === "ArrowRight") {
    keyboardHorizontal();
  }
  if (key === "a" || key === "d") {
    objektDrehen(key);
  }
};

document.onkeyup = function (element) {
  const key = element.key;
  keyaction.delete(key);
  keyboardDown();
};

function keyboardDown() {
  if (keyaction.has("ArrowDown")) {
    fps = 30;
    clearInterval(interval);
    intervalSetzen();
  } else {
    fps = 0.5;
    clearInterval(interval);
    intervalSetzen();
  }
}

function keyboardHorizontal() {
  const werte = puffer[0].map((element) => element % 20);
  linksVonSichKeineTeile();
  rechtsVonSichKeineTeile();
  const rightprüfen = (element) =>
    pixel[element + 1].style.backgroundColor !== "black";
  const leftprüfen = (element) =>
    pixel[element - 1].style.backgroundColor !== "black";

  if (
    keyaction.has("ArrowLeft") &&
    Math.min.apply(null, werte) !== 0 &&
    !keyaction.has("ArrowRight") &&
    linksprüfenaufblack.every(leftprüfen)
  ) {
    vorgängerLöschen(puffer[0]); //hier 1
    //puffer[1] = puffer[1].map((element) => element - 1);
    puffer[0] = puffer[0].map((element) => element - 1);
    objekte[zufallszahl] = objekte[zufallszahl].map((element) => element - 1);

    körperMalen(puffer[0]); //hier 1
  } else if (
    keyaction.has("ArrowRight") &&
    Math.max.apply(null, werte) !== 19 &&
    !keyaction.has("ArrowLeft") &&
    rechtsprüfenaufblack.every(rightprüfen)
  ) {
    vorgängerLöschen(puffer[0]); //hier 1
    //puffer[1] = puffer[1].map((element) => element + 1);
    puffer[0] = puffer[0].map((element) => element + 1);
    objekte[zufallszahl] = objekte[zufallszahl].map((element) => element + 1);

    körperMalen(puffer[0]); //hier 1
  }
}

function linksVonSichKeineTeile() {
  linksprüfenaufblack = [];
  for (let i = 0; i < puffer[0].length; i++) {
    if (!puffer[0].includes(puffer[0][i] - 1)) {
      linksprüfenaufblack.push(puffer[0][i]);
    }
  }
} //hier komplett 1

function rechtsVonSichKeineTeile() {
  rechtsprüfenaufblack = [];
  for (let i = 0; i < puffer[0].length; i++) {
    if (!puffer[0].includes(puffer[0][i] + 1)) {
      rechtsprüfenaufblack.push(puffer[0][i]);
    }
  }
} //hier komplett 1

function objektDrehen(taste) {
  const zentrum = puffer[0][2];
  const zentrumspalte = zentrum % 20;
  const zentrumzeile = Math.round(zentrum / 20 - 0.5);
  let pufferwertedrehung = [];
  let zeilen = [];
  let spalten = [];

  for (let i = 0; i < puffer[0].length; i++) {
    if (i !== 2) {
      zeilen.push(Math.round(puffer[0][i] / 20 - 0.5) - zentrumzeile);
      spalten.push((puffer[0][i] % 20) - zentrumspalte);
    } else {
      zeilen.push(0);
      spalten.push(0);
    }
  }
  if (taste === "d") {
    for (let i = 0; i < puffer[0].length; i++) {
      let wertnachdrehung = zentrum + (spalten[i] * 20 - zeilen[i]);
      pufferwertedrehung.push(wertnachdrehung);
    }
  } else if (taste === "a") {
    for (let i = 0; i < puffer[0].length; i++) {
      pufferwertedrehung.push(zentrum - (spalten[i] * 20 - zeilen[i]));
    }
  }

  //pufferWerte2();
  //puffer[0] = pufferwertedrehung;

  //TODO:hier eventuell obekt=puffer[0]
  //puffer[1] alter Körper && puffer[0] ist neue Körper

  let anfangswerte;
  let endwerte;

  let anfangminzeile;
  let anfangmaxzeile;
  let anfangminspalte;
  let anfangmaxspalte;
  let endeminzeile;
  let endemaxzeile;
  let endeminspalte;
  let endemaxspalte;
  let anfangzeilewertebereich;
  let anfangspaltewertebereich;
  let endezeilewertebereich;
  let endespaltewertebereich;

  let anfang1 = pufferwertedrehung.slice(2, 5); //hier puffer[0]
  let anfang2 = puffer[0].slice(3, 5); //hier puffer[1]
  let ende1 = pufferwertedrehung.slice(0, 3); //hier puffer[0]
  let ende2 = puffer[0].slice(0, 2); //hier puffer[1]

  anfangswerte = [...anfang1, ...anfang2];
  endwerte = [...ende1, ...ende2];

  if (zufallszahl !== 3) {
    let zeileninobjektend = new Set([]);
    let zeileninobjektanfang = new Set([]);

    for (let i = 0; i < endwerte.length; i++) {
      zeileninobjektend.add(Math.round(endwerte[i] / 20 - 0.5));
    }
    for (let i = 0; i < anfangswerte.length; i++) {
      zeileninobjektanfang.add(Math.round(anfangswerte[i] / 20 - 0.5));
    }
    for (let i = 0; i < endwerte.length; i++) {
      let minusende = endwerte[i] - 20;
      let plusende = endwerte[i] + 20;
      if (
        zeileninobjektend.has(Math.round(minusende / 20 - 0.5)) &&
        !endwerte.includes(minusende)
      ) {
        endwerte.push(minusende);
      } else if (
        zeileninobjektend.has(Math.round(plusende / 20 - 0.5)) &&
        !endwerte.includes(plusende)
      ) {
        endwerte.push(plusende);
      }
    }
    for (let i = 0; i < anfangswerte.length; i++) {
      let minusanfang = anfangswerte[i] - 20;
      let plusanfang = anfangswerte[i] + 20;
      if (
        zeileninobjektanfang.has(Math.round(minusanfang / 20 - 0.5)) &&
        !anfangswerte.includes(minusanfang)
      ) {
        anfangswerte.push(minusanfang);
      } else if (
        zeileninobjektanfang.has(Math.round(plusanfang / 20 - 0.5)) &&
        !anfangswerte.includes(plusanfang)
      ) {
        anfangswerte.push(plusanfang);
      }
    }
  }
  anfangminzeile = Math.min.apply(
    null,
    anfangswerte.map((element) => Math.round(element / 20 - 0.5))
  );
  anfangminspalte = Math.min.apply(
    null,
    anfangswerte.map((element) => element % 20)
  );
  anfangmaxzeile = Math.max.apply(
    null,
    anfangswerte.map((element) => Math.round(element / 20 - 0.5))
  );
  anfangmaxspalte = Math.max.apply(
    null,
    anfangswerte.map((element) => element % 20)
  );
  endeminzeile = Math.min.apply(
    null,
    endwerte.map((element) => Math.round(element / 20 - 0.5))
  );
  endeminspalte = Math.min.apply(
    null,
    endwerte.map((element) => element % 20)
  );
  endemaxzeile = Math.max.apply(
    null,
    endwerte.map((element) => Math.round(element / 20 - 0.5))
  );
  endemaxspalte = Math.max.apply(
    null,
    endwerte.map((element) => element % 20)
  );

  anfangzeilewertebereich = anfangmaxzeile - anfangminzeile + 1;
  anfangspaltewertebereich = anfangmaxspalte - anfangminspalte + 1;
  endezeilewertebereich = endemaxzeile - endeminzeile + 1;
  endespaltewertebereich = endemaxspalte - endeminspalte + 1;

  let anfangstart = Math.min.apply(null, anfangswerte);
  let endestart = Math.min.apply(null, endwerte);

  for (
    let i = anfangstart;
    i < anfangstart + 20 * anfangzeilewertebereich;
    i += 20
  ) {
    for (let z = i; z < i + 1 * anfangspaltewertebereich; z++) {
      if (!anfangswerte.includes(z)) {
        anfangswerte.push(z);
      }
    }
  }

  for (let i = endestart; i < endestart + 20 * endezeilewertebereich; i += 20) {
    for (let z = i; z < i + 1 * endespaltewertebereich; z++) {
      if (!endwerte.includes(z)) {
        endwerte.push(z);
      }
    }
  }

  let verfügbaranfang = [];
  for (let index = 0; index < anfangswerte.length; index++) {
    if (!puffer[0].includes(anfangswerte[index])) {
      verfügbaranfang.push(anfangswerte[index]);
    }
  }

  let verfügbarende = [];
  for (let index = 0; index < endwerte.length; index++) {
    if (!puffer[0].includes(endwerte[index])) {
      verfügbarende.push(endwerte[index]);
    }
  }

  let blackorwhite = (element) =>
    pixel[element].style.backgroundColor !== "black";

  if (
    verfügbaranfang.every(blackorwhite) &&
    verfügbarende.every(blackorwhite)
  ) {
    objekte[zufallszahl] = pufferwertedrehung.map((element) => element + 20); //hier puffer[0]
    vorgängerLöschen(puffer[0]); //hier 1
    puffer[0] = pufferwertedrehung;
    körperMalen(puffer[0]);
  } else {
    //puffer[0] = puffer[1];
  }
}
