"use strict";

let zaehler = 1;
let objekte;
let pixel;
let puffer = [,];
let zufallszahl;
let interval;
let maxfelder = [];
let schalter = true;
let keyaction = new Set([]);
let fps = 0.5;
let linksprüfenaufblack;
let linksprüfenaufblackverfügbar;
let rechtsprüfenaufblack;
let rechtsprüfenaufblackverfügbar;
let klappe = true;
let verfügbarobjekt;
let verfügbarkeitpuffer;
let schalterkeydown = 0;
let index3 = 0;
let zazaza = 1;
let anzahlreihen = 0;

objekteWertzurücksetzung();
zufallsZahlFürObjekt();
feldAusfüllen();
intervalSetzen();

function objekteWertzurücksetzung() {
  objekte = [
    [-31, -10, -30, -50, -29],
    [-32, -12, -11, -10, -9],
    [-29, -9, -10, -11, -12],
    [-90, -70, -50, -30, -10],
  ];
}

function zufallsZahlFürObjekt() {
  zufallszahl = Math.round(Math.random() * objekte.length - 0.5);
}

function feldAusfüllen() {
  for (let i = 0; i < 500; i++) {
    const element = document.createElement("div");
    document.querySelector("#spielfeld").appendChild(element);
    element.classList = "pixel " + zaehler;
    zaehler++;
  }
  zaehler = 0;
  pixel = document.querySelectorAll(".pixel");
}

function intervalSetzen() {
  interval = setInterval(function () {
    window.requestAnimationFrame(function () {
      GameOverOrNot(anzahlreihen);
      verfügbarkeitObjekt();
      zeileErmitteln();
      trueOrFalse();
      objektMalen(verfügbarobjekt);
      volleReihe();
      restartInterval();
      objekteWerteNeusetzen();
    });
  }, 1000 / fps);
}

function verfügbarkeitObjekt() {
  verfügbarobjekt = [];

  for (let i = 0; i < objekte[zufallszahl].length; i++) {
    if (objekte[zufallszahl][i] >= 0) {
      verfügbarobjekt.push(objekte[zufallszahl][i]);
    }
  }
}

function zeileErmitteln() {
  if (Math.max.apply(null, verfügbarobjekt) < 500) {
    for (let i = 0; i < verfügbarobjekt.length; i++) {
      if (!verfügbarobjekt.includes(verfügbarobjekt[i] + 20)) {
        maxfelder.push(verfügbarobjekt[i]);
      }
    }
  }
}

function trueOrFalse() {
  const prüfen = (element) => pixel[element].style.backgroundColor !== "black";
  if (Math.max.apply(null, verfügbarobjekt) < 500 && maxfelder.every(prüfen)) {
    schalter = true;
  } else {
    schalter = false;
    zaehler = 0;
  }
  maxfelder = [];
}

function objektMalen(element) {
  if (schalter) {
    pufferWerte();
    körperMalen(element);
    zaehler++;
  }
}

function pufferWerte() {
  //Alter Werte werden zwischengespeichert und genutzt.
  if (zaehler > 0) {
    vorgängerLöschen(puffer[0]);
  }
  puffer[0] = objekte[zufallszahl];
}

function vorgängerLöschen(nr) {
  verfügbarkeitpuffer = [];
  for (let i = 0; i < nr.length; i++) {
    if (puffer[0][i] >= 0) {
      verfügbarkeitpuffer.push(nr[i]);
    }
  }
  for (let i = 0; i < verfügbarkeitpuffer.length; i++) {
    pixel[verfügbarkeitpuffer[i]].style.backgroundColor = "orangered";
  }
}

function körperMalen(object) {
  let koerperpuffer = [];
  for (let i = 0; i < object.length; i++) {
    if (object[i] >= 0) {
      koerperpuffer.push(object[i]);
    }
  }
  for (let i = 0; i < koerperpuffer.length; i++) {
    pixel[koerperpuffer[i]].style.backgroundColor = "black";
  }
}

function istUnterseiteImFeld(elementarray) {
  const spielkörperunterseite = elementarray;
  let isblack = (element) =>
    pixel[element + 20].style.backgroundColor === "black";

  if (
    index3 === 0 &&
    pixel[Math.max.apply(null, spielkörperunterseite) + 20].style
      .backgroundColor === "black"
  ) {
    index3++;
    return true;
  } else if (index3 > 0 && spielkörperunterseite.some(isblack)) {
    index3++;
    return true;
  } else {
    index3++;
    return false;
  }
}

function volleReihe() {
  anzahlreihen = 0;
  const zeile = puffer[0].map((element) => Math.round(element / 20 - 0.5));
  let unterseite = [];
  for (let i = 0; i < puffer[0].length; i++) {
    if (!puffer[0].includes(puffer[0][i] + 20)) {
      unterseite.push(puffer[0][i]);
    }
  }

  if (Math.max.apply(null, zeile) === 24 || istUnterseiteImFeld(unterseite)) {
    console.log(1);
    let vollereihe = [[], [], [], [], []];
    let zeilenimbereich = [];

    for (let i = 0; i < zeile.length; i++) {
      if (zeile[i] >= 0) {
        zeilenimbereich.push(zeile[i]);
      }
    }

    for (let x = 0; x < zeilenimbereich.length; x++) {
      for (
        let i = zeilenimbereich[x] * 20;
        i < zeilenimbereich[x] * 20 + 20;
        i++
      ) {
        if (pixel[i].style.backgroundColor === "black") {
          vollereihe[x].push(true);
        } else {
          vollereihe[x].push(false);
        }
      }
    }

    const völleprüfen = (element) => element === true;

    for (let x = 0; x < zeilenimbereich.length; x++) {
      if (vollereihe[x].every(völleprüfen)) {
        for (
          let i = zeilenimbereich[x] * 20;
          i < zeilenimbereich[x] * 20 + 20;
          i++
        ) {
          pixel[i].style.backgroundColor = "orangered";
        }
        anzahlreihen++;
      }
    }
    if (anzahlreihen > 0) {
      schalter = false;
      puffer[0] = [];

      //TODO:Hier auch ein GameOver einbauen... HIIIIIIIIEEEERRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
      //Versuch mal einen allgemeinen GameOver zu entwickeln, der allgemein klappt.

      restartInterval();
      nachReihevollAlleReihenNachUntenVerschieben();
    }
  }
}

function GameOverOrNot(element2) {
  const isblack = (element) => pixel[element].style.backgroundColor === "black";
  const ispositive = (element) => element >= 0;
  if (objekte[zufallszahl].some(ispositive)) {
    let objuntereseite = [];
    const maxzeile = Math.round(
      Math.max.apply(
        null,
        objekte[zufallszahl].map((element) => element / 20 - 0.5)
      )
    );
    for (let i = 0; i < objekte[zufallszahl].length; i++) {
      if (Math.round(objekte[zufallszahl][i] / 20 - 0.5) === maxzeile) {
        objuntereseite.push(Math.round(objekte[zufallszahl][i]));
      }
    }

    if (Math.max.apply(null, objekte[zufallszahl]) < 499) {
      if (objuntereseite.some(isblack)) {
        let ermittlermaxzeileminusbereich = Math.round(
          Math.min.apply(null, objekte[zufallszahl]) / 20 - 0.5
        );
        if (ermittlermaxzeileminusbereich - element2 < 0) {
          clearInterval(interval);
          console.log("Game Over!");
        }
      }
    }
  }
}

function restartInterval(element) {
  if (!schalter) {
    clearInterval(interval);
    zufallsZahlFürObjekt();
    objekteWertzurücksetzung();
    intervalSetzen();
  }
}

function objekteWerteNeusetzen() {
  objekte[zufallszahl] = objekte[zufallszahl].map((x) => x + 20);
}

document.onkeydown = function (element) {
  const key = element.key;
  keyaction.add(key);
  if (key === "ArrowDown") {
    keyboardDown();
  }

  if (
    (key === "ArrowLeft" || key === "ArrowRight") &&
    schalter &&
    zazaza !== 0
  ) {
    keyboardHorizontal();
  }
  if (key === "a" || key === "d") {
    objektDrehen(key);
  }
};

document.onkeyup = function (element) {
  const key = element.key;
  keyaction.delete(key);
  keyboardDown();
};

function keyboardDown() {
  if (keyaction.has("ArrowDown")) {
    if (schalterkeydown === 0) {
      fps = 30;
      clearInterval(interval);
      intervalSetzen();
      schalterkeydown++;
    }
  } else {
    fps = 0.5;
    clearInterval(interval);
    intervalSetzen();
    schalterkeydown = 0;
  }
}

function keyboardHorizontal() {
  let imfeld = [];
  let nichtimfeld = [];

  let imfeldsetspalten;
  let nichtimfeldsetspalten;

  let imfeldsetspalten2;
  let nichtimfeldsetspalten2;

  if (puffer[0] !== undefined) {
    for (let i = 0; i < puffer[0].length; i++) {
      if (puffer[0][i] >= 0) {
        imfeld.push(puffer[0][i]);
      } else {
        nichtimfeld.push(puffer[0][i]);
      }
    }

    linksVonSichKeineTeile(imfeld);
    rechtsVonSichKeineTeile(imfeld);

    imfeldsetspalten = new Set(imfeld.map((element) => element % 20));
    nichtimfeldsetspalten = new Set(nichtimfeld.map((element) => element % 20));

    imfeldsetspalten2 = Array.from(imfeldsetspalten);
    nichtimfeldsetspalten2 = Array.from(nichtimfeldsetspalten);

    const rightprüfen = (element) =>
      pixel[element + 1].style.backgroundColor !== "black";
    const leftprüfen = (element) =>
      pixel[element - 1].style.backgroundColor !== "black";

    if (
      keyaction.has("ArrowLeft") &&
      Math.min.apply(null, imfeldsetspalten2) !== 0 &&
      Math.max.apply(null, nichtimfeldsetspalten2) !== -0 &&
      !keyaction.has("ArrowRight") &&
      linksprüfenaufblack.every(leftprüfen)
    ) {
      vorgängerLöschen(puffer[0]);
      puffer[0] = puffer[0].map((element) => element - 1);
      objekte[zufallszahl] = objekte[zufallszahl].map((element) => element - 1);

      körperMalen(puffer[0]);
    } else if (
      keyaction.has("ArrowRight") &&
      Math.max.apply(null, imfeldsetspalten2) !== 19 &&
      Math.max.apply(null, nichtimfeldsetspalten2) !== -1 &&
      !keyaction.has("ArrowLeft") &&
      rechtsprüfenaufblack.every(rightprüfen)
    ) {
      vorgängerLöschen(puffer[0]);
      puffer[0] = puffer[0].map((element) => element + 1);
      objekte[zufallszahl] = objekte[zufallszahl].map((element) => element + 1);

      körperMalen(puffer[0]);
    }
  } else {
    const werte = objekte[zufallszahl].map((element) => element % 20);

    if (
      keyaction.has("ArrowLeft") &&
      Math.max.apply(null, werte) !== -0 &&
      !keyaction.has("ArrowRight")
    ) {
      objekte[zufallszahl] = objekte[zufallszahl].map((element) => element - 1);
    } else if (
      keyaction.has("ArrowRight") &&
      Math.max.apply(null, werte) !== -1 &&
      !keyaction.has("ArrowLeft")
    ) {
      objekte[zufallszahl] = objekte[zufallszahl].map((element) => element + 1);
    }
  }
}

function linksVonSichKeineTeile(arrelement) {
  linksprüfenaufblack = [];
  for (let i = 0; i < arrelement.length; i++) {
    if (!arrelement.includes(arrelement[i] - 1)) {
      linksprüfenaufblack.push(arrelement[i]);
    }
  }
}

function rechtsVonSichKeineTeile(arrelement) {
  rechtsprüfenaufblack = [];
  for (let i = 0; i < arrelement.length; i++) {
    if (!arrelement.includes(arrelement[i] + 1)) {
      rechtsprüfenaufblack.push(arrelement[i]);
    }
  }
}

function objektDrehen(taste) {
  const zentrum = puffer[0][2];
  const zentrumspalte = zentrum % 20;
  const zentrumzeile = Math.round(zentrum / 20 - 0.5);
  let pufferwertedrehung = [];
  let zeilen = [];
  let spalten = [];

  for (let i = 0; i < puffer[0].length; i++) {
    if (i !== 2) {
      zeilen.push(Math.round(puffer[0][i] / 20 - 0.5) - zentrumzeile);
      spalten.push((puffer[0][i] % 20) - zentrumspalte);
    } else {
      zeilen.push(0);
      spalten.push(0);
    }
  }
  if (taste === "d") {
    for (let i = 0; i < puffer[0].length; i++) {
      let wertnachdrehung = zentrum + (spalten[i] * 20 - zeilen[i]);
      pufferwertedrehung.push(wertnachdrehung);
    }
  } else if (taste === "a") {
    for (let i = 0; i < puffer[0].length; i++) {
      pufferwertedrehung.push(zentrum - (spalten[i] * 20 - zeilen[i]));
    }
  }

  if (linksUndRechtsAufGrenzenPrüfen(pufferwertedrehung)) {
    let anfangswerte;
    let endwerte;

    let anfangminzeile;
    let anfangmaxzeile;
    let anfangminspalte;
    let anfangmaxspalte;
    let endeminzeile;
    let endemaxzeile;
    let endeminspalte;
    let endemaxspalte;
    let anfangzeilewertebereich;
    let anfangspaltewertebereich;
    let endezeilewertebereich;
    let endespaltewertebereich;

    let anfang1 = pufferwertedrehung.slice(2, 5);
    let anfang2 = puffer[0].slice(3, 5);
    let ende1 = pufferwertedrehung.slice(0, 3);
    let ende2 = puffer[0].slice(0, 2);

    anfangswerte = [...anfang1, ...anfang2];
    endwerte = [...ende1, ...ende2];

    if (zufallszahl !== 3) {
      let zeileninobjektend = new Set([]);
      let zeileninobjektanfang = new Set([]);

      for (let i = 0; i < endwerte.length; i++) {
        zeileninobjektend.add(Math.round(endwerte[i] / 20 - 0.5));
      }
      for (let i = 0; i < anfangswerte.length; i++) {
        zeileninobjektanfang.add(Math.round(anfangswerte[i] / 20 - 0.5));
      }
      for (let i = 0; i < endwerte.length; i++) {
        let minusende = endwerte[i] - 20;
        let plusende = endwerte[i] + 20;
        if (
          zeileninobjektend.has(Math.round(minusende / 20 - 0.5)) &&
          !endwerte.includes(minusende)
        ) {
          endwerte.push(minusende);
        } else if (
          zeileninobjektend.has(Math.round(plusende / 20 - 0.5)) &&
          !endwerte.includes(plusende)
        ) {
          endwerte.push(plusende);
        }
      }
      for (let i = 0; i < anfangswerte.length; i++) {
        let minusanfang = anfangswerte[i] - 20;
        let plusanfang = anfangswerte[i] + 20;
        if (
          zeileninobjektanfang.has(Math.round(minusanfang / 20 - 0.5)) &&
          !anfangswerte.includes(minusanfang)
        ) {
          anfangswerte.push(minusanfang);
        } else if (
          zeileninobjektanfang.has(Math.round(plusanfang / 20 - 0.5)) &&
          !anfangswerte.includes(plusanfang)
        ) {
          anfangswerte.push(plusanfang);
        }
      }
    }
    anfangminzeile = Math.min.apply(
      null,
      anfangswerte.map((element) => Math.round(element / 20 - 0.5))
    );
    anfangminspalte = Math.min.apply(
      null,
      anfangswerte.map((element) => element % 20)
    );
    anfangmaxzeile = Math.max.apply(
      null,
      anfangswerte.map((element) => Math.round(element / 20 - 0.5))
    );
    anfangmaxspalte = Math.max.apply(
      null,
      anfangswerte.map((element) => element % 20)
    );
    endeminzeile = Math.min.apply(
      null,
      endwerte.map((element) => Math.round(element / 20 - 0.5))
    );
    endeminspalte = Math.min.apply(
      null,
      endwerte.map((element) => element % 20)
    );
    endemaxzeile = Math.max.apply(
      null,
      endwerte.map((element) => Math.round(element / 20 - 0.5))
    );
    endemaxspalte = Math.max.apply(
      null,
      endwerte.map((element) => element % 20)
    );

    anfangzeilewertebereich = anfangmaxzeile - anfangminzeile + 1;
    anfangspaltewertebereich = anfangmaxspalte - anfangminspalte + 1;
    endezeilewertebereich = endemaxzeile - endeminzeile + 1;
    endespaltewertebereich = endemaxspalte - endeminspalte + 1;

    let anfangstart = Math.min.apply(null, anfangswerte);
    let endestart = Math.min.apply(null, endwerte);

    for (
      let i = anfangstart;
      i < anfangstart + 20 * anfangzeilewertebereich;
      i += 20
    ) {
      for (let z = i; z < i + 1 * anfangspaltewertebereich; z++) {
        if (!anfangswerte.includes(z)) {
          anfangswerte.push(z);
        }
      }
    }

    for (
      let i = endestart;
      i < endestart + 20 * endezeilewertebereich;
      i += 20
    ) {
      for (let z = i; z < i + 1 * endespaltewertebereich; z++) {
        if (!endwerte.includes(z)) {
          endwerte.push(z);
        }
      }
    }

    let verfügbaranfang = [];
    for (let index = 0; index < anfangswerte.length; index++) {
      if (!puffer[0].includes(anfangswerte[index])) {
        verfügbaranfang.push(anfangswerte[index]);
      }
    }

    let verfügbarende = [];
    for (let index = 0; index < endwerte.length; index++) {
      if (!puffer[0].includes(endwerte[index])) {
        verfügbarende.push(endwerte[index]);
      }
    }

    let blackorwhite = (element) =>
      pixel[element].style.backgroundColor !== "black";

    if (
      verfügbaranfang.every(blackorwhite) &&
      verfügbarende.every(blackorwhite)
    ) {
      objekte[zufallszahl] = pufferwertedrehung.map((element) => element + 20);
      vorgängerLöschen(puffer[0]);
      puffer[0] = pufferwertedrehung;
      körperMalen(puffer[0]);
    }
  }
}

function linksUndRechtsAufGrenzenPrüfen(arrElement) {
  let arraytosort = arrElement.map((element) => element % 20);
  const arraylength = arraytosort.length;
  let sortedarray = [];

  for (let i = 0; i < arraylength; i++) {
    let min = Math.min.apply(null, arraytosort);
    sortedarray.push(min);
    arraytosort.splice(arraytosort.indexOf(min), 1);
  }

  const arraytoset = new Set(sortedarray);
  const settoarray = Array.from(arraytoset);

  for (let i = 0; i < settoarray.length - 1; i++) {
    if (settoarray[i + 1] - settoarray[i] > 1) {
      return false;
    }
  }
  return true;
}

function nachReihevollAlleReihenNachUntenVerschieben() {
  const anzahlreihen = 25;
  let reihenanalyse = [];
  let pufferfürreihe = [];
  let index = 0;

  for (let i = 0; i < 25; i++) {
    reihenanalyse.push([]);
  }

  for (let i = 0; i < 25 * 20; i += 20) {
    for (let z = i; z < i + 20; z++) {
      reihenanalyse[i / 20].push(z);
    }
  }

  let isblack = (element) => pixel[element].style.backgroundColor === "black";

  for (let i = 0; i < 25; i++) {
    if (reihenanalyse[i].some(isblack)) {
      pufferfürreihe.push(reihenanalyse[i]);
    }
  }

  let sammler = [];

  for (let i = 0; i < pufferfürreihe.length; i++) {
    for (let v = 0; v < pufferfürreihe[i].length; v++) {
      if (pixel[pufferfürreihe[i][v]].style.backgroundColor === "black") {
        sammler.push(pufferfürreihe[i][v] % 20);
      }
    }
    pufferfürreihe[i] = sammler;
    sammler = [];
  }

  for (let i = 0; i < reihenanalyse.length; i++) {
    reihenanalyse[i].forEach(
      (element) => (pixel[element].style.backgroundColor = "orangered")
    );
  }

  const anzahlzeilen = 25;
  const anfangzeile = anzahlzeilen - pufferfürreihe.length;
  let schlussendlichmalen = [];
  for (let i = anfangzeile; i < anzahlzeilen; i++) {
    schlussendlichmalen = schlussendlichmalen.concat(
      pufferfürreihe[i - anfangzeile].map((element) => i * 20 + element)
    );
  }

  schlussendlichmalen.forEach(
    (element) => (pixel[element].style.backgroundColor = "black")
  );
}
