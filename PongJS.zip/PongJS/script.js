var ball = document.querySelector("#ball").style;
var spieler = document.querySelectorAll(".spieler");
for (let i = 0; i < spieler.length; i++) {
  spieler[i].style.top = 120 + "px";
}
var ballkox;
var ballkoy;
var bally;
var ballx;
var schritt = 0;
var key = [];
var kdelete = [];
var k;
var k2;
var xspieler1 = 0;
var xspieler2 = 0;
var direction = [];
for (let i = 0; i < 34; i++) {
  direction.push((68 - i) / 34);
}
for (let i = 33; i >= 0; i--) {
  direction.push((68 - i) / 34);
}

let interval;

let interval2;

//Button-Start definieren
document.querySelector("#start").onclick = function () {
  if (schritt == 0) {
    ballkox = 246;
    ballkoy = Math.round(Math.random() * 289);
    if (ballkoy % 2 != 0) {
      ballkoy++;
    }

    ball.display = "block";
    ballx = Math.random() * 4 - 2;
    bally = Math.random() * 4 - 2;
    if (ballx < 0) {
      ballx = -2;
    } else {
      ballx = 2;
    }

    if (bally < 0) {
      bally = -2;
    } else {
      bally = 2;
    }

    interval = window.requestAnimationFrame(inter);
    interval2 = window.requestAnimationFrame(inter2);
    schritt++;
  }
};

function inter2() {
  if (kdelete.length > 0) {
    console.log(kdelete.length);
    for (let i = 0; i < kdelete.length; i++) {
      key.splice(key.indexOf(kdelete[i]), 1);
    }

    kdelete = [];
    console.log(kdelete.length);
  }

  if (key.includes("w") == true && key.includes("s") == false) {
    xspieler1 = -2;
  } else if (key.includes("s") == true && key.includes("w") == false) {
    xspieler1 = 2;
  } else {
    xspieler1 = 0;
  }
  if (key.includes("ArrowUp") == true && key.includes("ArrowDown") == false) {
    xspieler2 = -2;
  } else if (
    key.includes("ArrowDown") == true &&
    key.includes("ArrowUp") == false
  ) {
    xspieler2 = 2;
  } else {
    xspieler2 = 0;
  }

  if (
    (parseInt(spieler[0].style.top) > 0 &&
      parseInt(spieler[0].style.top) <= 240 &&
      xspieler1 == -2) ||
    (parseInt(spieler[0].style.top) >= 0 &&
      parseInt(spieler[0].style.top) < 240 &&
      xspieler1 == 2)
  ) {
    spieler[0].style.top = parseInt(spieler[0].style.top) + xspieler1 + "px";
  }
  if (
    (parseInt(spieler[1].style.top) > 0 &&
      parseInt(spieler[1].style.top) <= 240 &&
      xspieler2 == -2) ||
    (parseInt(spieler[1].style.top) >= 0 &&
      parseInt(spieler[1].style.top) < 240 &&
      xspieler2 == 2)
  ) {
    spieler[1].style.top = parseInt(spieler[1].style.top) + xspieler2 + "px";
  }
  window.requestAnimationFrame(inter2);
}
var hahavor;
function inter() {
  hahavor = ball.left;
  console.log(hahavor);
  ball.left = ballkox + "px";
  ball.top = ballkoy + "px";
  hahavor = ball.left;
  console.log(hahavor);
  if (parseInt(ball.left) >= 490 || parseInt(ball.left) <= 0) {
    clearInterval(interval);
    clearInterval(interval2);
    setTimeout(function () {
      window.alert("Game Over");
      key = [];
      ball.display = "none";
      schritt = 0;
    }, 10);
  } else {
    if (parseInt(ball.top) <= 0 || parseInt(ball.top) >= 290) {
      bally = -bally;
    }

    if (
      parseInt(ball.left) == 6 &&
      parseInt(ball.top) >= parseInt(spieler[0].style.top) - 9 &&
      parseInt(ball.top) <= parseInt(spieler[0].style.top) + 59
    ) {
      for (let i = 0; i < 68; i++) {
        if (parseInt(ball.top) + 10 - parseInt(spieler[0].style.top) == i + 1) {
          if (bally > 0) {
            if (i < 34) {
              bally = bally / direction[i];
            } else if (i < 68) {
              bally = bally * direction[i];
            }
          } else {
            if (i < 34) {
              bally = bally * direction[i];
            } else if (i < 68) {
              bally = bally / direction[i];
            }
          }
        }
      }
      ballx = -ballx;
    } else if (
      parseInt(ball.left) == 486 &&
      parseInt(ball.top) >= parseInt(spieler[1].style.top) - 9 &&
      parseInt(ball.top) <= parseInt(spieler[1].style.top) + 59
    ) {
      for (let i = 0; i < 68; i++) {
        if (parseInt(ball.top) + 10 - parseInt(spieler[1].style.top) == i + 1) {
          if (bally > 0) {
            if (i < 34) {
              bally = bally / direction[i];
            } else if (i < 68) {
              bally = bally * direction[i];
            }
          } else {
            if (i < 34) {
              bally = bally * direction[i];
            } else if (i < 68) {
              bally = bally / direction[i];
            }
          }
        }
      }
      ballx = -ballx;
    }

    ballkox += ballx;
    ballkoy += bally;
    window.requestAnimationFrame(inter);
  }
}

document.onkeyup = function (element) {
  k2 = element.key;
  if (
    (k2 == "w" || k2 == "s" || k2 == "ArrowUp" || k2 == "ArrowDown") &&
    kdelete.indexOf(k2) < 0
  ) {
    kdelete.push(k2);
  }
};

document.onkeydown = function (element) {
  k = element.key;
  if (
    (k == "w" || k == "s" || k == "ArrowUp" || k == "ArrowDown") &&
    key.indexOf(k) < 0
  ) {
    key.push(k);
  }
};

//TODO: nächstes Projekt Bomberman
